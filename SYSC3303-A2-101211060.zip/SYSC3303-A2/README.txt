Written By Nicholas Nemec - 101211060
SYSC3303 Assignment 2

In the src directory you will find three java class files, Client, IntermediateHost and Server.
There is no "required" setup but if you wish to change the message being sent by the client you must
ensure that it is 20 characters or shorter. The code functions with the example given in the outline of
having a message structured like 01test.txt0mode0 or 02test.txt0mode0, the code will have to be adapted to be
more robust should more rigorus testing be required. But for the purpose of this assignment it functions as
intended.